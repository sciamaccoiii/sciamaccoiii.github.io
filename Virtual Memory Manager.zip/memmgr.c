//
//  memmgr.c
//  memmgr
//
//  Created by William McCarthy on 17/11/20.
//  Copyright © 2020 William McCarthy. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>

#define ARGC_ERROR 1
#define FILE_ERROR 2
#define BUFLEN 256
#define FRAME_SIZE  256


//-------------------------------------------------------------------
unsigned getpage(unsigned x) { return (0xff00 & x) >> 8; }

unsigned getoffset(unsigned x) { return (0xff & x); }

void getpage_offset(unsigned x) {
  unsigned  page   = getpage(x);
  unsigned  offset = getoffset(x);
  printf("x is: %u, page: %u, offset: %u, address: %u, paddress: %u\n", x, page, offset,
         (page << 8) | getoffset(x), page * 256 + offset);
}

int main(int argc, const char* argv[]) {
  FILE* fadd = fopen("addresses.txt", "r");    // open file addresses.txt  (contains the logical addresses)
  if (fadd == NULL) { fprintf(stderr, "Could not open file: 'addresses.txt'\n");  exit(FILE_ERROR);  }

  FILE* fcorr = fopen("correct.txt", "r");     // contains the logical and physical address, and its value
  if (fcorr == NULL) { fprintf(stderr, "Could not open file: 'correct.txt'\n");  exit(FILE_ERROR);  }

  char buf[BUFLEN];
  unsigned   page, offset, physical_add, frame = 0;
  unsigned   logic_add;                  // read from file address.txt
  unsigned   virt_add, phys_add, value;  // read from file correct.txt

  printf("ONLY READ FIRST 20 entries -- TODO: change to read all entries\n\n");

  // not quite correct -- should search page table before creating a new entry
  unsigned page_table[256] = {NULL};    //   e.g., address # 25 from addresses.txt will fail the assertion
  unsigned tlb[16][2] = {NULL};    // TODO:  add page table code
  int fault = 0;  //page fault counter
  int hit = 0;    //TLB hit counter
  unsigned val;

  FILE* fbin = fopen("BACKING_STORE.bin", "r");       //open BACKING_STORE
  if (fbin == NULL) { fprintf(stderr, "Could not open file: 'BACKING_STORE.bin'\n"); exit(FILE_ERROR); }
      // TODO:  add TLB code
  
  while (frame < 128) {

    fscanf(fcorr, "%s %s %d %s %s %d %s %d", buf, buf, &virt_add,
           buf, buf, &phys_add, buf, &value);  // read from file correct.txt

    fscanf(fadd, "%d", &logic_add);  // read from file address.txt
    page   = getpage(  logic_add);
    offset = getoffset(logic_add);
    
    physical_add = frame++ * FRAME_SIZE + offset;
    
  for (int i = 0; i < 16; i++) {
      if (tlb[i][0] == page) { //check TLB.  If present, increase hit counter, get frame number, and break loop to proceed.
        hit++;
        page = tlb[i][1];
        break;
      }
      if (i == 15 && tlb[15][0] != page) {  //If not present in TLB, check page table.
        for (int j = 0; j < 256; j++) {
          if (page_table[j] == page) {  //If present in page table, update TLB and proceed as before.
            for (int k = 0; k < 16; k++) {
              if (tlb[k][0] == NULL) { //check if empty
                tlb[k][0] = page;
              }
              if (k == 15 && tlb[15][0] != NULL) { //if no empty spaces, empty entire table and return to beginning.
                unsigned scrubber[16][2] = {NULL};
                tlb = scrubber;
                k = -1;
              }
            }
            break;
          }
          if (j == 255 && page_table[255] != page) { //If not present, increase fault counter, read BACKING_STORE, then update table and TLB
            fault++;
            fscanf(fbin, "%d", &page);
            for (int k = 0; k < 16; k++) {
              if (tlb[k][0] == NULL) { //check if empty
                tlb[k][0] = page;
              }
              if (k == 15 && tlb[15][0] != NULL) { //if no empty spaces, empty entire table and return to beginning.
                unsigned scrubber[16][2] = {NULL};
                tlb = scrubber;
                k = -1;
              }
            }
            page_table[page] = page;
          }
        }
      }
    }

    assert(physical_add == phys_add);
    
    
    
    fscanf(fbin, "%d", &val); //read BACKING_STORE and confirm value matches read value from correct.txt
    assert(val == value);

    printf("logical: %5u (page: %3u, offset: %3u) ---> physical: %5u -- passed\n", logic_add, page, offset, physical_add);
    if (frame % 5 == 0) { printf("\n"); }
  }
  fclose(fcorr);
  fclose(fadd);
  fclose(fbin);
  
  //printf("ONLY READ FIRST 20 entries -- TODO: change to read all entries\n\n");
  
  printf("ALL logical ---> physical assertions PASSED!\n");
  printf("Page-fault rate: ");
  printf((fault / 256) * 100);
  printf("%\n");
  printf("TLB hit rate: ");
  printf((hit / 256) * 100);
  printf("%\n");
  //printf("!!! This doesn't work passed entry 24 in correct.txt, because of a duplicate page table entry\n");
 // printf("--- you have to implement the PTE and TLB part of this code\n");

//  printf("NOT CORRECT -- ONLY READ FIRST 20 ENTRIES... TODO: MAKE IT READ ALL ENTRIES\n");

  printf("\n\t\t...done.\n");
  return 0;
}
