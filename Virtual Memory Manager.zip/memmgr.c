//
//  memmgr.c
//  memmgr
//
//  Created by William McCarthy on 17/11/20.
//  Copyright © 2020 William McCarthy. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>

#define ARGC_ERROR 1
#define FILE_ERROR 2
#define BUFLEN 256
#define FRAME_SIZE  256


//-------------------------------------------------------------------
unsigned getpage(unsigned x) { return (0xff00 & x) >> 8; }

unsigned getoffset(unsigned x) { return (0xff & x); }

void getpage_offset(unsigned x) {
  unsigned  page   = getpage(x);
  unsigned  offset = getoffset(x);
  printf("x is: %u, page: %u, offset: %u, address: %u, paddress: %u\n", x, page, offset,
         (page << 8) | getoffset(x), page * 256 + offset);
}

int main(int argc, const char* argv[]) {
  FILE* fadd = fopen("addresses.txt", "r");    // open file addresses.txt  (contains the logical addresses)
  if (fadd == NULL) { fprintf(stderr, "Could not open file: 'addresses.txt'\n");  exit(FILE_ERROR);  }

  FILE* fcorr = fopen("correct.txt", "r");     // contains the logical and physical address, and its value
  if (fcorr == NULL) { fprintf(stderr, "Could not open file: 'correct.txt'\n");  exit(FILE_ERROR);  }

  char buf[BUFLEN];
  unsigned   page, offset, physical_add, frame = 0;
  unsigned   logic_add;                  // read from file address.txt
  unsigned   virt_add, phys_add, value;  // read from file correct.txt

  char *memory[128] = {NULL};
  unsigned memory_index = 0;
  unsigned page_table[256];

  for (int s = 0; s < 256; s++) {   //I initialized the page table to fill all entries with 300 to avoid confusion when frame = 0
    page_table[s] = 300;
  }

  unsigned tlb[16][2] = {NULL};
  int fault = 1;  //page fault counter
  int hit = 0;  //TLB hit counter
  unsigned val;
  unsigned tlb_index = 0;

  while (frame < 244) {

    fscanf(fcorr, "%s %s %d %s %s %d %s %d", buf, buf, &virt_add,
           buf, buf, &phys_add, buf, &value);  // read from file correct.txt

    fscanf(fadd, "%d", &logic_add);  // read from file address.txt
    page   = getpage(  logic_add);
    offset = getoffset(logic_add);

  //  printf("%3u\n", page);
  //  printf("%3u\n", offset);

    for (int i = 0; i < 16; i++) {    //search TLB
      if (tlb[i][0] == page) {
        physical_add = tlb[i][1] * FRAME_SIZE + offset;
        hit++;
        break;
      }
      else if (i == 15 && tlb[15][0] != page) { //if not present in TLB, search page table
        if (page_table[page] != 300) {
      //    printf("DUPLICATE PAGE NUMBER SHOWED UP\n");
      //    printf("RETRIEVING CORRECT FRAME NUMBER\n");
          physical_add = page_table[page] * FRAME_SIZE + offset;
          tlb[tlb_index][0] = page;
          tlb[tlb_index][1] = page_table[page];
          tlb_index++;
          if (tlb_index == 16) {
            tlb_index = 0;
          }
      }
      else {
    //    printf("EMPTY ENTRY\n");
        fault++;
        FILE* fbin = fopen("BACKING_STORE.bin", "rb");
  //      printf("ATTEMPTING SEEK\n");
        fseek(fbin, (page * 256), SEEK_SET);
        char *test;
        test = malloc(256);
        fread(test, sizeof(char), 256, fbin);
        memory[memory_index] = test;
        memory_index++;

        if (memory_index == 128) {
          memory_index = 0;
        }

        page_table[page] = frame;
        physical_add = frame++ * FRAME_SIZE + offset;
        tlb[tlb_index][0] = page;
        tlb[tlb_index][1] = page_table[page];
        tlb_index++;
        if (tlb_index == 16) {
          tlb_index = 0;
        }
        fclose(fbin);
      }
    }
}

//    printf("%u\n", frame);
//    printf("%u\n", physical_add);
//    printf("%u\n", phys_add);

    assert(physical_add == phys_add);


    printf("logical: %5u (page: %3u, offset: %3u) ---> physical: %5u -- passed\n", logic_add, page, offset, physical_add);
    if (frame % 5 == 0) { printf("\n"); }
  }
  fclose(fcorr);
  fclose(fadd);


  printf("ALL logical ---> physical assertions PASSED!\n");

  float hit_percent = ((float)hit / 1000) * 100;
  printf("TLB hit rate: %.1f%\n", hit_percent);
  float fault_percent = ((float)fault / 1000) * 100;
  printf("Page fault rate: %.1f%\n", fault_percent);

  printf("\n\t\t...done.\n");
  return 0;
}
