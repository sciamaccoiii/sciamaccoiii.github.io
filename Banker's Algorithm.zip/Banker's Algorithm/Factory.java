//

// Factory class that creates the bank and each bank customer

// Usage:  java Factory 10 5 7

import java.io.*;

import java.util.*;

public class Factory {

    public static void main(String[] args) {

        String filename = "/Users/Scribe/eclipse-workspace/Banker's Algorithm/infile.txt";
        File file = new File(filename);
        StringBuilder contents = new StringBuilder();
        try {
        	Scanner scan = new Scanner(file);
        	while (scan.hasNextLine()) {
        		String line = scan.nextLine();
        		contents.append(line);
        	}
        	scan.close();
        } catch (FileNotFoundException fnfe) { 
        	throw new Error("Unable to find file \"" + filename + "\"");
        	}
        String input = String.valueOf(contents);
        
        int nResources = args.length;

        int[] resources = new int[nResources];

        for (int i = 0; i < nResources; i++) { 
        	resources[i] = Integer.parseInt(args[i].trim()); 
        	}

        Bank theBank = new BankImpl(resources);

        int[] maxDemand = new int[nResources];

        int[] allocated = new int[nResources];

        Thread[] workers = new Thread[Customer.COUNT];      // the customers

        Scanner scan2 = new Scanner(input);// read in values and initialize the matrices
        int elem = 0;
        while (scan2.hasNextLine()) {
        	allocated[elem] = scan2.nextInt();
        	elem++;
        	allocated[elem] = scan2.nextInt();
        	elem++;
        	allocated[elem] = scan2.nextInt();
        	elem++;
        	maxDemand[elem] = scan2.nextInt();
        	elem++;
        	maxDemand[elem] = scan2.nextInt();
        	elem++;
        	maxDemand[elem] = scan2.nextInt();
        	elem++;
        }
        scan2.close();

        // ...
        for (int threadNum = 0; threadNum < workers.length; threadNum++) {
                workers[threadNum] = new Thread(new Customer(threadNum, maxDemand, theBank));

                theBank.addCustomer(threadNum, allocated, maxDemand);

               // ++threadNum;        //theBank.getCustomer(threadNum);

               // resourceNum = 0;

        }

         
        // catch (IOException ioe) { throw new Error("Error processing \"" + filename + "\""); }

        System.out.println("FACTORY: created threads");     // start the customers

        for (int i = 0; i < Customer.COUNT; i++) { 
        	workers[i].start();
        	}

        System.out.println("FACTORY: started threads");
        }
}

