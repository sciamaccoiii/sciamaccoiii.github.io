//

// implementation of the Bank

//

import java.io.*;

import java.util.*;

public class BankImpl implements Bank {

    private int n;          // the number of threads in the system

    private int m;          // the number of resources

    private int[] available;    // the amount available of each resource

    private int[][] maximum;    // the maximum demand of each thread

    private int[][] allocation; // the amount currently allocated to each thread

    private int[][] need;       // the remaining needs of each thread

    private void showAllMatrices(int[][] alloc, int[][] max, int[][] need, String msg) { 
    	System.out.println(msg);
    	showMatrix(alloc, "Allocated", "Allocated");
    	showMatrix(max, "Maximum", "Maximum");
    	showMatrix(need, "Need", "Need");

    }

 

    private void showMatrix(int[][] matrix, String title, String rowTitle) {
    	System.out.println(title);
    	for (int i = 0; i < matrix.length; i++) {
    		System.out.println(rowTitle);
    		for (int j = 0; j <matrix[i].length; j++) {
    			System.out.print(matrix[i][j] + " ");
    		}
    		System.out.println("");
    	}
    }

    private void showVector(int[] vect, String msg) {
    	System.out.println(msg);
    	for (int i = 0; i < vect.length; i++) {
    		System.out.println(vect[i] + " ");
    	}
    	System.out.println("");
    }

    public BankImpl(int[] resources) {      // create a new bank (with resources)
    	this.n = n;
    	this.m = m;
    	this.available = resources;
    	this.maximum = maximum;
    	this.allocation = allocation;
    	this.need = need;
    }

                               // invoked by a thread when it enters the system;  also records max demand

    public void addCustomer(int threadNum, int[] allocated, int[] maxDemand) {
    	Bank theBank = new BankImpl(allocated);
    	Customer custom = new Customer(threadNum, maxDemand, theBank);
   }

    public void getState() {        // output state for each thread

       showVector(available, "Available");
       showAllMatrices(allocation, maximum, need, "Allocation, Max, and Need"); // outputs available, allocation, max, and need matrices
       
       
        requestResources(n, available);// request resources; specify number of customer being added, maxDemand for customer

        //      returns if request is grant

    }

    private boolean isSafeState (int threadNum, int[] request) {
    	{ 
    	    int count=0;
    	      
    	    boolean visited[] = new boolean[n];  
    	    for (int i = 0;i < n; i++) { 
    	        visited[i] = false; 
    	    } 
    	          
    	    int work[] = new int[m];     
    	    for (int i = 0;i < m; i++) { 
    	        work[i] = available[i]; 
    	    } 
    	  
    	    while (count<n) { 
    	        boolean flag = false; 
    	        for (int i = 0;i < n; i++) { 
    	            if (visited[i] == false) { 
    	            int j; 
    	            for (j = 0; j < m; j++) {         
    	                if (need[i][j] > work[j]) {
    	                break;
    	                }
    	            } 
    	            if (j == m) { 
    	               request[count++]=i; 
    	               visited[i]=true; 
    	               flag=true; 
    	                          
    	                for (j = 0; j < m; j++) { 
    	                work[j] = work[j] + allocation[i][j]; 
    	                } 
    	            } 
    	          } 
    	        } 
    	        if (flag == false) { 
    	            break; 
    	        } 
    	    } 
    	    if (count < n) { 
    	        System.out.println("The system is not safe.");
    	        return false;
    	    } 
    	    else { 
    	        System.out.println("The system is safe.");
    	        return true;
    	        } 
    	    } 
    	}

                                // make request for resources. will block until request is satisfied safely

    public synchronized boolean requestResources(int threadNum, int[] request)  {
    	boolean flag = false;
    	while (flag == false) {
    		if (isSafeState(threadNum, request) == true) {
    			flag = true;
    		}
    	}
        return true;
     }

    public synchronized void releaseResources(int threadNum, int[] release)  {

        for (int i = 0; i < threadNum; i++) {
        	release[i] = 0;
        }

}
}